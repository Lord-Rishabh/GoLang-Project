package cmd

import (
	"fmt"
)

func main() {
	fmt.Print("hello");
}